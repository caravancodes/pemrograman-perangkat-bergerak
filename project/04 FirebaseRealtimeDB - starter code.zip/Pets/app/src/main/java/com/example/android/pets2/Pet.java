package com.example.android.pets2;

public class Pet {
    private String mName;
    private String mBreed;

    //TODO (3) create constructor, setter and getter
}
