package com.example.android.pets2;

//TODO (7) extend RecyclerView.Adapter and implements required methods
public class PetAdapter {
    //TODO (8) addChildEventListener for our real-time database in constructor

    //TODO (5) create interface to handle click event

    //TODO (6) create inner class for ViewHolder
}
