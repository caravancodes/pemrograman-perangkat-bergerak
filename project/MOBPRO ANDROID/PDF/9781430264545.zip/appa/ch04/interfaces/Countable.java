public interface Countable
{
   String getID();
}