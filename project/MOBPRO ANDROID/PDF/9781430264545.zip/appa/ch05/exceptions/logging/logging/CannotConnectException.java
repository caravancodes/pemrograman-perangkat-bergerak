package logging;

public class CannotConnectException extends Exception
{
}