package logging;

public class NotConnectedException extends Exception
{
}