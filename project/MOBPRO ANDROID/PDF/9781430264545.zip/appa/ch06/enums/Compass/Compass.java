enum Compass
{
   NORTH, SOUTH, EAST, WEST
}