public class HelloWorld extends android.app.Activity
{
   public void create(android.os.Bundle savedInstanceState)
   {
      super.onCreate(savedInstanceState);
      System.out.println("Hello, World!");
   }
}