public class CompoundExpressions
{
   public static void main(String[] args)
   {
      int age = 65;
      System.out.println(age + 32);
      System.out.println(++age);
      System.out.println(age--);
      System.out.println("A" + "B");
      System.out.println("A" + 5);
      short x = 32767;
      System.out.println(++x);
   }
}