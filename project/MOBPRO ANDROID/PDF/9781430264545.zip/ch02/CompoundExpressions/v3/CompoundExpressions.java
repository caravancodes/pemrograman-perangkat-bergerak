public class CompoundExpressions
{
   public static void main(String[] args)
   {
      System.out.println(~181);
      System.out.println(26 & 183);
      System.out.println(26 ^ 183);
      System.out.println(26 | 183);
   }
}