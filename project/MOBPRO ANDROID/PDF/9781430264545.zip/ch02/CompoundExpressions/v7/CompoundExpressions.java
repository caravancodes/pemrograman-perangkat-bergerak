public class CompoundExpressions
{
   public static void main(String[] args)
   {
      short age = 65;
      System.out.println(age * 1000);
      System.out.println(1.0 / 0.0);
      System.out.println(10 % 4);
      System.out.println(3 / 0);
   }
}