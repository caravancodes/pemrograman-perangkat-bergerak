public class CompoundExpressions
{
   public static void main(String[] args)
   {
      System.out.println(2 << 3);
      System.out.println(16 >> 3);
      System.out.println(-4 >> 1);
      System.out.println(-4 >>> 1);
   }
}