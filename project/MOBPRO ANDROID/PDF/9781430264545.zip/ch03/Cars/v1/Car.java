class Car
{
   static int counter = 0;

   Car()
   {
      counter++;
   }
}