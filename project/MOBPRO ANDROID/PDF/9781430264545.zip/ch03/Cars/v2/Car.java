class Car
{
   String make;
   String model;
   int numDoors;
}