class Employee
{
   final static int RETIREMENT_AGE = 65;
}