class Employee
{
   final int RETIREMENT_AGE = 65;
}