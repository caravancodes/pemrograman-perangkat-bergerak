class Shape
{
   void draw()
   {
   }
}