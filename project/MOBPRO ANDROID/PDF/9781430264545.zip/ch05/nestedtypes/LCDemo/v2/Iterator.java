interface Iterator
{
   boolean hasMoreElements();
   Object nextElement();
}