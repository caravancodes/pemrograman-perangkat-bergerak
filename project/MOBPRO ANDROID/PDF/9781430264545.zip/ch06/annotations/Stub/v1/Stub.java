public @interface Stub
{
}