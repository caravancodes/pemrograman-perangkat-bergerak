public @interface Stub
{
   String value();
}