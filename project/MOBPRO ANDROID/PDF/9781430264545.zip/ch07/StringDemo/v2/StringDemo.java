public class StringDemo
{
   public static void main(String[] args)
   {
      String s = "abc"; 
      for (int i = 0; i < s.length(); i++)
         System.out.println(s.charAt(i));
   }
}