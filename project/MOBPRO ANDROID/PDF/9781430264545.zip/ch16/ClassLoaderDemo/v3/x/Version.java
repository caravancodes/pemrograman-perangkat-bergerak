public class Version
{
   public static void main(String[] args)
   {
      System.out.println("Version 1");
   }
}